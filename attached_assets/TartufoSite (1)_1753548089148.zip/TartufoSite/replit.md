# Event Management System

## Overview

This is a full-stack Event Management System built with React frontend and Express.js backend. The application allows students to register for events and provides administrators with comprehensive event management capabilities. The system features custom email/password authentication, role-based access control, student registration, event creation/management, and real-time dashboards.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Form Handling**: React Hook Form with Zod validation
- **Routing**: Wouter for client-side routing

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: OpenID Connect (OIDC) with Replit Auth
- **Session Management**: Express session with PostgreSQL store
- **Password Hashing**: bcrypt for secure password storage
- **API Design**: RESTful API endpoints with validation

### Database Architecture
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Connection**: Neon serverless PostgreSQL driver
- **Schema**: Shared schema definitions between frontend and backend
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Authentication System
- **Provider**: Custom email/password authentication with bcrypt hashing
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **Role-based Access**: Students and Admin roles with different permissions
- **Security**: HTTP-only cookies, secure session management, password validation
- **Admin Credentials**: view123@gmail.com / View@123
- **Student Email Format**: Must end with @view.edu.in (e.g., 21XM1A0501@view.edu.in)
- **Password Requirements**: Must contain uppercase, number, and special character

### User Management
- **Students**: Registration with roll number, email, phone, branch, and year
- **Admins**: Special privileges for event management
- **Profile Management**: User profile information from OIDC provider

### Event System
- **Event Creation**: Admins can create events with title, description, date, venue
- **Event Registration**: Students can register for available events
- **Event Categories**: Support for different event types (cultural, technical, sports)
- **Capacity Management**: Event registration limits and tracking

### Dashboard Features
- **Student Dashboard**: View available events, registered events, and statistics
- **Admin Dashboard**: Event management, student management, analytics
- **Real-time Updates**: Live statistics and registration counts

## Data Flow

### Authentication Flow
1. User enters email and password on landing page
2. Server validates credentials against database
3. Password hash verified using bcrypt
4. Session created and stored in PostgreSQL
5. User role determined (student/admin)
6. Dashboard rendered based on role

### Event Registration Flow
1. Student views available events
2. Student clicks register for event
3. Backend validates registration eligibility
4. Registration record created in database
5. Real-time updates sent to dashboards

### Admin Management Flow
1. Admin creates/edits events
2. Form validation with Zod schemas
3. Database updates through Drizzle ORM
4. Real-time updates to all connected clients

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver
- **drizzle-orm**: Type-safe ORM for database operations
- **@radix-ui/**: Accessible UI component primitives
- **@tanstack/react-query**: Server state management
- **openid-client**: OIDC authentication
- **bcrypt**: Password hashing

### Development Tools
- **TypeScript**: Type safety across the stack
- **Vite**: Fast development server and build tool
- **Tailwind CSS**: Utility-first CSS framework
- **Zod**: Schema validation for forms and API

### UI Components
- Comprehensive component library from shadcn/ui
- Consistent design system with CSS custom properties
- Responsive design with mobile-first approach

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild bundles Node.js server to `dist/index.js`
- **Assets**: Static assets served from build directory

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption key (defaults to 'dev-secret-key' in development)

### Database Setup
- Drizzle migrations in `./migrations` directory
- Schema defined in `shared/schema.ts`
- Database push command: `npm run db:push`

### Production Deployment
- Node.js server serves both API and static files
- Express middleware handles API routes under `/api`
- Static file serving for production builds
- Environment-specific configurations for development/production

## Recent Changes

### January 26, 2025 - Custom Authentication Implementation
- **Replaced Replit Auth**: Switched from OpenID Connect to custom email/password authentication
- **Updated Database Schema**: Added `passwordHash` and `role` columns to users table
- **Enhanced Security**: Implemented bcrypt password hashing and validation
- **Admin User**: Automatically creates admin user (view123@gmail.com / View@123) on startup
- **Student Email Validation**: Enforces @view.edu.in domain for student registrations
- **Password Policy**: Requires uppercase letter, number, and special character

The application follows a monorepo structure with shared TypeScript schemas and utilities, ensuring type safety and consistency across the full stack. The architecture supports horizontal scaling and maintains clean separation of concerns between presentation, business logic, and data layers.