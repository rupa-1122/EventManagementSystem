import {
  users,
  students,
  events,
  eventRegistrations,
  eventCategories,
  studentEventPreferences,
  admins,
  type User,
  type UpsertUser,
  type Student,
  type InsertStudent,
  type Event,
  type InsertEvent,
  type EventRegistration,
  type InsertEventRegistration,
  type Admin,
  type InsertAdmin,
  type EventCategory,
  type InsertEventCategory,
  type StudentEventPreference,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Student operations
  getStudent(userId: string): Promise<Student | undefined>;
  getStudentByRollNumber(rollNumber: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  getAllStudents(): Promise<Student[]>;
  
  // Event operations
  getAllEvents(): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<Event>): Promise<Event>;
  deleteEvent(id: string): Promise<void>;
  
  // Event registration operations
  registerForEvent(registration: InsertEventRegistration): Promise<EventRegistration>;
  getEventRegistrations(eventId: string): Promise<EventRegistration[]>;
  getStudentRegistrations(studentId: string): Promise<EventRegistration[]>;
  isStudentRegistered(eventId: string, studentId: string): Promise<boolean>;
  
  // Admin operations
  getAdmin(userId: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  // Event category operations
  getAllEventCategories(): Promise<EventCategory[]>;
  getEventCategory(id: string): Promise<EventCategory | undefined>;
  createEventCategory(category: InsertEventCategory): Promise<EventCategory>;
  deleteEventCategory(id: string): Promise<void>;
  
  // Student event preferences
  createStudentEventPreferences(studentId: string, categoryIds: string[]): Promise<void>;
  getStudentEventPreferences(studentId: string): Promise<StudentEventPreference[]>;
  
  // Statistics
  getStudentStats(studentId: string): Promise<{
    registeredEvents: number;
    attendedEvents: number;
    points: number;
  }>;
  getAdminStats(): Promise<{
    totalEvents: number;
    totalStudents: number;
    totalRegistrations: number;
    activeEvents: number;
  }>;
  
  // Recent activity
  getRecentActivity(): Promise<Array<{
    id: string;
    studentName: string;
    eventName: string;
    timestamp: Date;
    type: 'registration' | 'new_student';
  }>>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Student operations
  async getStudent(userId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.userId, userId));
    return student;
  }

  async getStudentByRollNumber(rollNumber: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.rollNumber, rollNumber));
    return student;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(students);
  }

  // Event operations
  async getAllEvents(): Promise<Event[]> {
    return await db.select().from(events).orderBy(desc(events.createdAt));
  }

  async getEvent(id: string): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event;
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const eventWithSeats = {
      ...event,
      availableSeats: event.totalSeats,
    };
    const [newEvent] = await db.insert(events).values(eventWithSeats).returning();
    return newEvent;
  }

  async updateEvent(id: string, eventData: Partial<Event>): Promise<Event> {
    const [updatedEvent] = await db
      .update(events)
      .set(eventData)
      .where(eq(events.id, id))
      .returning();
    return updatedEvent;
  }

  async deleteEvent(id: string): Promise<void> {
    // First delete all registrations for this event
    await db.delete(eventRegistrations).where(eq(eventRegistrations.eventId, id));
    // Then delete the event
    await db.delete(events).where(eq(events.id, id));
  }

  // Event registration operations
  async registerForEvent(registration: InsertEventRegistration): Promise<EventRegistration> {
    // Start a transaction to ensure atomicity
    const result = await db.transaction(async (tx) => {
      // Insert the registration
      const [newRegistration] = await tx
        .insert(eventRegistrations)
        .values(registration)
        .returning();

      // Decrease available seats
      await tx
        .update(events)
        .set({
          availableSeats: sql`${events.availableSeats} - 1`,
        })
        .where(eq(events.id, registration.eventId));

      return newRegistration;
    });

    return result;
  }

  async getEventRegistrations(eventId: string): Promise<EventRegistration[]> {
    return await db
      .select()
      .from(eventRegistrations)
      .where(eq(eventRegistrations.eventId, eventId));
  }

  async getStudentRegistrations(studentId: string): Promise<EventRegistration[]> {
    return await db
      .select()
      .from(eventRegistrations)
      .where(eq(eventRegistrations.studentId, studentId));
  }

  async isStudentRegistered(eventId: string, studentId: string): Promise<boolean> {
    const [registration] = await db
      .select()
      .from(eventRegistrations)
      .where(
        sql`${eventRegistrations.eventId} = ${eventId} AND ${eventRegistrations.studentId} = ${studentId}`
      );
    return !!registration;
  }

  // Admin operations
  async getAdmin(userId: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.userId, userId));
    return admin;
  }

  async createAdmin(admin: InsertAdmin): Promise<Admin> {
    const [newAdmin] = await db.insert(admins).values(admin).returning();
    return newAdmin;
  }

  // Event category operations
  async getAllEventCategories(): Promise<EventCategory[]> {
    return await db.select().from(eventCategories).orderBy(eventCategories.name);
  }

  async getEventCategory(id: string): Promise<EventCategory | undefined> {
    const [category] = await db.select().from(eventCategories).where(eq(eventCategories.id, id));
    return category;
  }

  async createEventCategory(category: InsertEventCategory): Promise<EventCategory> {
    const [newCategory] = await db.insert(eventCategories).values(category).returning();
    return newCategory;
  }

  async deleteEventCategory(id: string): Promise<void> {
    await db.delete(eventCategories).where(eq(eventCategories.id, id));
  }

  // Student event preferences
  async createStudentEventPreferences(studentId: string, categoryIds: string[]): Promise<void> {
    const preferences = categoryIds.map(categoryId => ({
      studentId,
      categoryId,
    }));
    
    await db.insert(studentEventPreferences).values(preferences);
  }

  async getStudentEventPreferences(studentId: string): Promise<StudentEventPreference[]> {
    return await db
      .select()
      .from(studentEventPreferences)
      .where(eq(studentEventPreferences.studentId, studentId));
  }

  // Statistics
  async getStudentStats(studentId: string): Promise<{
    registeredEvents: number;
    attendedEvents: number;
    points: number;
  }> {
    const registrations = await this.getStudentRegistrations(studentId);
    return {
      registeredEvents: registrations.length,
      attendedEvents: Math.floor(registrations.length * 0.7), // Simulate 70% attendance
      points: registrations.length * 50, // 50 points per event
    };
  }

  async getAdminStats(): Promise<{
    totalEvents: number;
    totalStudents: number;
    totalRegistrations: number;
    activeEvents: number;
  }> {
    const [eventsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(events);

    const [studentsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(students);

    const [registrationsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(eventRegistrations);

    const [activeEventsCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(events)
      .where(sql`${events.availableSeats} > 0`);

    return {
      totalEvents: Number(eventsCount.count),
      totalStudents: Number(studentsCount.count),
      totalRegistrations: Number(registrationsCount.count),
      activeEvents: Number(activeEventsCount.count),
    };
  }

  // Recent activity
  async getRecentActivity(): Promise<Array<{
    id: string;
    studentName: string;
    eventName: string;
    timestamp: Date;
    type: 'registration' | 'new_student';
  }>> {
    const recentRegistrations = await db
      .select({
        id: eventRegistrations.id,
        studentName: sql<string>`${users.firstName} || ' ' || ${users.lastName}`,
        eventName: events.title,
        timestamp: eventRegistrations.registeredAt,
        type: sql<'registration'>`'registration'`,
      })
      .from(eventRegistrations)
      .innerJoin(students, eq(eventRegistrations.studentId, students.id))
      .innerJoin(users, eq(students.userId, users.id))
      .innerJoin(events, eq(eventRegistrations.eventId, events.id))
      .orderBy(desc(eventRegistrations.registeredAt))
      .limit(10);

    return recentRegistrations.map(activity => ({
      ...activity,
      timestamp: activity.timestamp || new Date(),
    }));
  }
}

export const storage = new DatabaseStorage();
