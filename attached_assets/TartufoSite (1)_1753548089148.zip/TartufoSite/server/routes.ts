import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./auth";
import { 
  studentRegistrationSchema, 
  loginSchema, 
  insertEventSchema,
  insertEventRegistrationSchema,
  insertEventCategorySchema,
} from "@shared/schema";
import { ZodError } from "zod";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Login endpoint
  app.post('/api/login', async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValid = await bcrypt.compare(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      res.json({ message: "Login successful", user: { ...user, passwordHash: undefined } });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Logout endpoint
  app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user is student or admin
      let student = null;
      let admin = null;
      
      if (user.role === 'student') {
        student = await storage.getStudent(user.id);
      } else if (user.role === 'admin') {
        admin = await storage.getAdmin(user.id);
      }

      res.json({
        ...user,
        passwordHash: undefined, // Don't send password hash
        student,
        admin,
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Student registration
  app.post('/api/register/student', async (req, res) => {
    try {
      const validatedData = studentRegistrationSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }

      // Check if student already exists
      const existingStudent = await storage.getStudentByRollNumber(validatedData.rollNumber);
      if (existingStudent) {
        return res.status(400).json({ message: "Student with this roll number already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);

      // Create user first
      const user = await storage.createUser({
        email: validatedData.email,
        firstName: validatedData.name.split(' ')[0],
        lastName: validatedData.name.split(' ').slice(1).join(' ') || '',
        passwordHash: hashedPassword,
        role: "student",
      });

      // Create student
      const student = await storage.createStudent({
        userId: user.id,
        name: validatedData.name,
        rollNumber: validatedData.rollNumber,
        phone: validatedData.phone,
        branch: validatedData.branch,
        year: validatedData.year,
      });

      // Save event preferences
      if (validatedData.eventCategories && validatedData.eventCategories.length > 0) {
        await storage.createStudentEventPreferences(student.id, validatedData.eventCategories);
      }

      res.json({ message: "Student registered successfully", student });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register student" });
    }
  });

  // Get all events
  app.get('/api/events', async (req, res) => {
    try {
      const events = await storage.getAllEvents();
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Create event (admin only)
  app.post('/api/events', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(validatedData);
      
      res.json(event);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error creating event:", error);
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  // Update event (admin only)
  app.put('/api/events/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const eventId = req.params.id;
      const event = await storage.updateEvent(eventId, req.body);
      
      res.json(event);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ message: "Failed to update event" });
    }
  });

  // Delete event (admin only)
  app.delete('/api/events/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const eventId = req.params.id;
      await storage.deleteEvent(eventId);
      
      res.json({ message: "Event deleted successfully" });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  // Register for event (students only)
  app.post('/api/events/:id/register', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'student') {
        return res.status(403).json({ message: "Student access required" });
      }

      const student = await storage.getStudent(user.id);
      if (!student) {
        return res.status(403).json({ message: "Student profile not found" });
      }

      const eventId = req.params.id;
      
      // Check if student is already registered
      const isRegistered = await storage.isStudentRegistered(eventId, student.id);
      if (isRegistered) {
        return res.status(400).json({ message: "Already registered for this event" });
      }

      // Check if event has available seats
      const event = await storage.getEvent(eventId);
      if (!event || event.availableSeats <= 0) {
        return res.status(400).json({ message: "No seats available" });
      }

      const registration = await storage.registerForEvent({
        eventId,
        studentId: student.id,
      });
      
      res.json(registration);
    } catch (error) {
      console.error("Error registering for event:", error);
      res.status(500).json({ message: "Failed to register for event" });
    }
  });

  // Get student statistics
  app.get('/api/student/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'student') {
        return res.status(403).json({ message: "Student access required" });
      }

      const student = await storage.getStudent(user.id);
      if (!student) {
        return res.status(403).json({ message: "Student profile not found" });
      }

      const stats = await storage.getStudentStats(student.id);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching student stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get admin statistics
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get recent activity (admin only)
  app.get('/api/admin/activity', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const activity = await storage.getRecentActivity();
      res.json(activity);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  // Get student registrations
  app.get('/api/student/registrations', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'student') {
        return res.status(403).json({ message: "Student access required" });
      }

      const student = await storage.getStudent(user.id);
      if (!student) {
        return res.status(403).json({ message: "Student profile not found" });
      }

      const registrations = await storage.getStudentRegistrations(student.id);
      res.json(registrations);
    } catch (error) {
      console.error("Error fetching registrations:", error);
      res.status(500).json({ message: "Failed to fetch registrations" });
    }
  });

  // Event category routes
  app.get('/api/event-categories', async (req, res) => {
    try {
      const categories = await storage.getAllEventCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching event categories:", error);
      res.status(500).json({ message: "Failed to fetch event categories" });
    }
  });

  app.post('/api/event-categories', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertEventCategorySchema.parse(req.body);
      const category = await storage.createEventCategory(validatedData);
      res.json(category);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error creating event category:", error);
      res.status(500).json({ message: "Failed to create event category" });
    }
  });

  app.delete('/api/event-categories/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      await storage.deleteEventCategory(req.params.id);
      res.json({ message: "Event category deleted successfully" });
    } catch (error) {
      console.error("Error deleting event category:", error);
      res.status(500).json({ message: "Failed to delete event category" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
