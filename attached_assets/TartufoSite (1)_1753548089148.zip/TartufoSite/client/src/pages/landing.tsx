import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { studentRegistrationSchema, type StudentRegistration, type EventCategory } from "@shared/schema";
import { GraduationCap, Shield, UserPlus, Info } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import emailjs from '@emailjs/browser';

type TabType = "login" | "admin";

export default function Landing() {
  const [activeTab, setActiveTab] = useState<TabType>("login");
  const [showRegisterDialog, setShowRegisterDialog] = useState(false);
  const { toast } = useToast();

  const registrationForm = useForm<StudentRegistration>({
    resolver: zodResolver(studentRegistrationSchema),
    defaultValues: {
      name: "",
      rollNumber: "",
      email: "",
      phone: "",
      branch: "",
      year: 1,
      password: "",
      eventCategories: [],
    },
  });

  // Fetch event categories for registration form
  const { data: eventCategories = [] } = useQuery<EventCategory[]>({
    queryKey: ["/api/event-categories"],
  });

  const registerMutation = useMutation({
    mutationFn: async (data: StudentRegistration) => {
      // Register student in database
      await apiRequest("POST", "/api/register/student", data);
      
      // Send welcome email via EmailJS
      const selectedCategories = eventCategories
        .filter(cat => data.eventCategories.includes(cat.id))
        .map(cat => cat.name)
        .join(", ");

      const emailParams = {
        to_name: data.name,
        to_email: data.email,
        student_name: data.name,
        roll_number: data.rollNumber,
        phone_number: data.phone,
        branch: data.branch,
        year: data.year,
        selected_events: selectedCategories || "None selected",
        message: `Welcome to Yuvatarang! Your registration has been confirmed. You can now login with your email (${data.email}) and participate in the selected events.`
      };

      await emailjs.send(
        'service_fkb2flr', // Service ID
        'template_bn5g7lg', // Template ID
        emailParams,
        '_5E3TBTSxOfgNVIWG' // Public Key
      );
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful",
        description: "Your account has been created and a confirmation email has been sent. Please log in with your credentials.",
      });
      setShowRegisterDialog(false);
      registrationForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
  });

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string; password: string }) => {
      await apiRequest("POST", "/api/login", data);
    },
    onSuccess: () => {
      toast({
        title: "Login Successful",
        description: "Welcome back!",
      });
      window.location.reload(); // Refresh to update auth state
    },
    onError: (error) => {
      toast({
        title: "Login Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(loginForm);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "login":
        return (
          <div className="max-w-md mx-auto">
            <Card>
              <CardContent className="pt-6 p-8">
                <div className="text-center mb-8">
                  <GraduationCap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-gray-900">Student Access</h2>
                  <p className="text-gray-600 mt-2">VIEW Events Portal</p>
                </div>
                
                <form onSubmit={handleLogin} className="space-y-6">
                  <div>
                    <Label htmlFor="student-email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address
                    </Label>
                    <Input
                      type="email"
                      id="student-email"
                      placeholder="21XM1A0501@view.edu.in"
                      className="w-full"
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="student-password" className="block text-sm font-medium text-gray-700 mb-2">
                      Password
                    </Label>
                    <Input
                      type="password"
                      id="student-password"
                      placeholder="••••••••"
                      className="w-full"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing In..." : "Sign In as Student"}
                  </Button>
                </form>
                
                <div className="mt-6 text-center">
                  <p className="text-sm text-gray-600 mb-3">
                    Don't have an account?
                  </p>
                  <Dialog open={showRegisterDialog} onOpenChange={setShowRegisterDialog}>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full border-blue-600 text-blue-600 hover:bg-blue-50"
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Register for Yuvatarang
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Register for Yuvatarang Fest</DialogTitle>
                      </DialogHeader>
                      <Form {...registrationForm}>
                        <form onSubmit={registrationForm.handleSubmit((data) => registerMutation.mutate(data))} className="space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={registrationForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Full Name *</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Enter your full name" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={registrationForm.control}
                              name="rollNumber"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Roll Number *</FormLabel>
                                  <FormControl>
                                    <Input placeholder="e.g., 21XM1A0501" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={registrationForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email Address *</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="email" 
                                      placeholder="21XM1A0501@view.edu.in" 
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={registrationForm.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone Number *</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="tel" 
                                      placeholder="9876543210" 
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField
                              control={registrationForm.control}
                              name="branch"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Branch *</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select your branch" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="CSE">Computer Science Engineering</SelectItem>
                                      <SelectItem value="ECE">Electronics & Communication</SelectItem>
                                      <SelectItem value="EEE">Electrical & Electronics</SelectItem>
                                      <SelectItem value="MECH">Mechanical Engineering</SelectItem>
                                      <SelectItem value="CIVIL">Civil Engineering</SelectItem>
                                      <SelectItem value="IT">Information Technology</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={registrationForm.control}
                              name="year"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Year of Study *</FormLabel>
                                  <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select year" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="1">1st Year</SelectItem>
                                      <SelectItem value="2">2nd Year</SelectItem>
                                      <SelectItem value="3">3rd Year</SelectItem>
                                      <SelectItem value="4">4th Year</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <FormField
                            control={registrationForm.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Password *</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password" 
                                    placeholder="Password (uppercase, number, special character required)" 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={registrationForm.control}
                            name="eventCategories"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Event Categories for Yuvatarang Fest *</FormLabel>
                                <div className="space-y-3">
                                  <p className="text-sm text-gray-600">Select the events you're interested in participating in:</p>
                                  <div className="grid grid-cols-2 gap-3">
                                    {eventCategories.map((category) => (
                                      <div key={category.id} className="flex items-center space-x-2">
                                        <Checkbox
                                          id={category.id}
                                          checked={field.value.includes(category.id)}
                                          onCheckedChange={(checked) => {
                                            const updatedCategories = checked
                                              ? [...field.value, category.id]
                                              : field.value.filter((id: string) => id !== category.id);
                                            field.onChange(updatedCategories);
                                          }}
                                        />
                                        <label 
                                          htmlFor={category.id} 
                                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                          {category.name}
                                        </label>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <Button 
                            type="submit" 
                            className="w-full bg-blue-600 hover:bg-blue-700"
                            disabled={registerMutation.isPending}
                          >
                            {registerMutation.isPending ? "Registering..." : "Register for Yuvatarang"}
                          </Button>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
            
            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex">
                <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-blue-800">Student Registration</h3>
                  <p className="text-sm text-blue-700 mt-1">
                    Students register with their VIEW email (format: 21XM1A0501@view.edu.in). Password must contain uppercase, number, and special character.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case "admin":
        return (
          <div className="max-w-md mx-auto">
            <Card>
              <CardContent className="pt-6 p-8">
                <div className="text-center mb-8">
                  <Shield className="h-12 w-12 text-red-600 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-gray-900">Admin Access</h2>
                  <p className="text-gray-600 mt-2">System Administration</p>
                </div>
                
                <form onSubmit={handleLogin} className="space-y-6">
                  <div>
                    <Label htmlFor="admin-email" className="block text-sm font-medium text-gray-700 mb-2">
                      Admin Email
                    </Label>
                    <Input
                      type="email"
                      id="admin-email"
                      placeholder="view123@gmail.com"
                      className="w-full"
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="admin-password" className="block text-sm font-medium text-gray-700 mb-2">
                      Password
                    </Label>
                    <Input
                      type="password"
                      id="admin-password"
                      placeholder="••••••••"
                      className="w-full"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      required
                    />
                  </div>
                  
                  <Button 
                    type="submit"
                    className="w-full bg-red-600 hover:bg-red-700"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing In..." : "Sign In as Admin"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-xl font-bold text-blue-600">Vignan's IEVW</h1>
                <p className="text-xs text-gray-600">Student Portal</p>
              </div>
            </div>
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => setActiveTab("login")}
                className={`px-1 pb-2 text-sm font-medium border-b-2 ${
                  activeTab === "login" 
                    ? "text-blue-600 border-blue-600" 
                    : "text-gray-500 hover:text-gray-700 border-transparent"
                }`}
              >
                Student Login
              </button>
              <button 
                onClick={() => setActiveTab("admin")}
                className={`px-1 pb-2 text-sm font-medium border-b-2 ${
                  activeTab === "admin" 
                    ? "text-blue-600 border-blue-600" 
                    : "text-gray-500 hover:text-gray-700 border-transparent"
                }`}
              >
                Admin Login
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderTabContent()}
      </main>
    </div>
  );
}